
# Responsepo

## Structure

`Responsepo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orginal_text` | `string` | Optional | - |
| `postag` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "orginalText": null,
  "postag": null
}
```

