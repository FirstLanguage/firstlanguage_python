
# Orignal String

## Structure

`OrignalString`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `morph_attr` | `List of string` | Optional | - |

## Example (as JSON)

```json
{
  "morph_attr": null
}
```

