
# Responseclassify

## Structure

`Responseclassify`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `List of string` | Optional | - |
| `scores` | `List of float` | Optional | - |

## Example (as JSON)

```json
{
  "labels": null,
  "scores": null
}
```

