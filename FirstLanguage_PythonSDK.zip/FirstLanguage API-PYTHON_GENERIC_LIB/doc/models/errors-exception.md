
# Errors Exception

## Structure

`ErrorsException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`List of Errors1`](/fl-python/doc/models/errors-1.md) | Optional | - |

## Example (as JSON)

```json
{
  "errors": null
}
```

