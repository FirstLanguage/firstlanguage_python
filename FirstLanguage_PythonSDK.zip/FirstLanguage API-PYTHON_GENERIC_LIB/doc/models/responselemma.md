
# Responselemma

## Structure

`Responselemma`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orginal_text` | `string` | Optional | - |
| `lemmatized` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "orginalText": null,
  "lemmatized": null
}
```

