
# Text Input Tamil

## Structure

`TextInputTamil`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Input4`](/fl-python/doc/models/input-4.md) | Optional | - |

## Example (as JSON)

```json
{
  "input": null
}
```

