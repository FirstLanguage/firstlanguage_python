
# Responsemorph

## Structure

`Responsemorph`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orignal_string` | [`OrignalString`](/fl-python/doc/models/orignal-string.md) | Optional | - |

## Example (as JSON)

```json
{
  "orignalString": null
}
```

