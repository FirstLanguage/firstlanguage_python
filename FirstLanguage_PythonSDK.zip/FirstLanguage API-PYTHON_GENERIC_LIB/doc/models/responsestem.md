
# Responsestem

## Structure

`Responsestem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orginal_text` | `string` | Optional | - |
| `stem` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "orginalText": null,
  "stem": null
}
```

