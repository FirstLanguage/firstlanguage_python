
# Api Lemmatize 426 Error

## Structure

`ApiLemmatize426Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": null
}
```

