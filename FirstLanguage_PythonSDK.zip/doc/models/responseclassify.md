
# Responseclassify

## Structure

`Responseclassify`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `string[] \| undefined` | Optional | - |
| `scores` | `number[] \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "labels": null,
  "scores": null
}
```

