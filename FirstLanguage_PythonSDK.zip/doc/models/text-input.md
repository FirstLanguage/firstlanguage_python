
# Text Input

## Structure

`TextInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Input \| undefined`](/doc/models/input.md) | Optional | Direct Text Input |

## Example (as JSON)

```json
{
  "input": null
}
```

