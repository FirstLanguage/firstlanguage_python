
# M426 Error

Please use HTTPS protocol

## Structure

`M426Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": null
}
```

