
# Text Input Classify

## Structure

`TextInputClassify`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Input2 \| undefined`](/doc/models/input-2.md) | Optional | - |

## Example (as JSON)

```json
{
  "input": null
}
```

