
# Api Postag 426 Error

## Structure

`ApiPostag426Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": null
}
```

