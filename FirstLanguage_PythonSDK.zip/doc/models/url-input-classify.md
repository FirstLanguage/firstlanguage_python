
# URL Input Classify

## Structure

`URLInputClassify`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Input3 \| undefined`](/doc/models/input-3.md) | Optional | - |

## Example (as JSON)

```json
{
  "input": null
}
```

