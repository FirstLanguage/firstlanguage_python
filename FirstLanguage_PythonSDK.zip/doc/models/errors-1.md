
# Errors 1

## Structure

`Errors1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `msg` | `string \| undefined` | Optional | - |
| `param` | `string \| undefined` | Optional | - |
| `location` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "msg": null,
  "param": null,
  "location": null
}
```

