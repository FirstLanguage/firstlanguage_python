
# Responselemma

## Structure

`Responselemma`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orginalText` | `string \| undefined` | Optional | - |
| `lemmatized` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "orginalText": null,
  "lemmatized": null
}
```

