
# Orignal String

## Structure

`OrignalString`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `morphAttr` | `string[] \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "morph_attr": null
}
```

