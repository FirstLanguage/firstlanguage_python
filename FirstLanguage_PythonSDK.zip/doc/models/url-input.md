
# URL Input

## Structure

`URLInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input` | [`Input1 \| undefined`](/doc/models/input-1.md) | Optional | Text for processing will be read from the given URL. Only HTML pages or text pages will be processed at this time. |

## Example (as JSON)

```json
{
  "input": null
}
```

