
# Responsestem

## Structure

`Responsestem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orginalText` | `string \| undefined` | Optional | - |
| `stem` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "orginalText": null,
  "stem": null
}
```

